
(function(exports){
  function isValidCPF(cpf){
    if(!cpf) return false;
    const onlyDigits = cpf.replace(/\D/g,'');
    if(onlyDigits.length !== 11) return false;
    if(/^(\d)\1+$/.test(onlyDigits)) return false;
    const nums = onlyDigits.split('').map(n=>+n);
    for(let t=9;t<11;t++){
      let d=0;
      for(let i=0;i<t;i++) d += nums[i]*(t+1-i);
      d = ((10 * d) % 11) % 10;
      if(d !== nums[t]) return false;
    }
    return true;
  }

  function showFieldError(input, message){
    const existing = input.parentElement.querySelector('.field-error');
    if(existing) existing.remove();
    input.setAttribute('aria-invalid','true');
    const div = document.createElement('div');
    div.className = 'field-error';
    div.style.color = 'var(--color-danger)';
    div.style.fontSize = '0.9rem';
    div.textContent = message;
    input.parentElement.appendChild(div);
  }

  function clearFieldError(input){
    input.removeAttribute('aria-invalid');
    const existing = input.parentElement.querySelector('.field-error');
    if(existing) existing.remove();
  }

  function validateForm(form){
    let valid = true;
    const nome = form.querySelector('#nome');
    const email = form.querySelector('#email');
    const cpf = form.querySelector('#cpf');
    const telefone = form.querySelector('#telefone');
    const nascimento = form.querySelector('#nascimento');
    const cep = form.querySelector('#cep');

    if(!nome.value || nome.value.trim().length < 3){
      showFieldError(nome, 'Informe o nome completo (mínimo 3 caracteres).');
      valid = false;
    } else clearFieldError(nome);

    const reEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if(!reEmail.test(email.value)){
      showFieldError(email, 'Informe um e-mail válido.');
      valid = false;
    } else clearFieldError(email);

    if(!isValidCPF(cpf.value)){
      showFieldError(cpf, 'CPF inválido.');
      valid = false;
    } else clearFieldError(cpf);

    const telDigits = telefone.value.replace(/\D/g,'');
    if(!(telDigits.length===10 || telDigits.length===11)){
      showFieldError(telefone, 'Telefone inválido (10 ou 11 números).');
      valid = false;
    } else clearFieldError(telefone);

    if(nascimento.value){
      const birth = new Date(nascimento.value);
      const ageDifMs = Date.now() - birth.getTime();
      const ageDate = new Date(ageDifMs);
      const age = Math.abs(ageDate.getUTCFullYear() - 1970);
      if(age < 16){
        showFieldError(nascimento, 'É necessário ter ao menos 16 anos para cadastrar-se.');
        valid = false;
      } else clearFieldError(nascimento);
    } else {
      showFieldError(nascimento, 'Informe a data de nascimento.');
      valid = false;
    }

    const cepDigits = cep.value.replace(/\D/g,'');
    if(cepDigits.length !== 8){
      showFieldError(cep, 'CEP inválido (8 dígitos).');
      valid = false;
    } else clearFieldError(cep);

    return valid;
  }

  exports.Validation = { isValidCPF, validateForm, showFieldError, clearFieldError };
})(window);
