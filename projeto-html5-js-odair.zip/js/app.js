
(function(){
  const routes = {
    '/': { template: 'home' },
    '/projetos': { template: 'projetos' },
    '/cadastro': { template: 'cadastro' }
  };

  const root = document.getElementById('app');

  function mountRoute(){
    const hash = location.hash.replace('#','') || '/';
    const route = routes[hash] || routes['/'];
    const draft = window.Storage ? window.Storage.loadDraft() : null;
    window.Templates.render(route.template, root, draft || {});
    afterRender(route.template);
  }

  function afterRender(templateName){
    const form = document.getElementById('cadastroForm');
    if(form){
      const cpf = form.querySelector('#cpf');
      const tel = form.querySelector('#telefone');
      const cep = form.querySelector('#cep');
      function formatCPF(v){ return v.replace(/\D/g,'').slice(0,11).replace(/(\d{3})(\d)/,'$1.$2').replace(/(\d{3})(\d)/,'$1.$2').replace(/(\d{3})(\d{1,2})$/,'$1-$2'); }
      function formatPhone(v){ return v.replace(/\D/g,'').slice(0,11).replace(/^(\d{2})(\d)/,'($1) $2').replace(/(\d{4,5})(\d{4})$/,'$1-$2'); }
      function formatCEP(v){ return v.replace(/\D/g,'').slice(0,8).replace(/(\d{5})(\d)/,'$1-$2'); }
      if(cpf) cpf.addEventListener('input', e=> e.target.value = formatCPF(e.target.value));
      if(tel) tel.addEventListener('input', e=> e.target.value = formatPhone(e.target.value));
      if(cep) cep.addEventListener('input', e=> e.target.value = formatCEP(e.target.value));

      const draft = window.Storage ? window.Storage.loadDraft() : null;
      if(draft){
        Object.keys(draft).forEach(k=>{
          const el = form.querySelector('[name="'+k+'"]');
          if(el) el.value = draft[k];
        });
      }

      form.addEventListener('input', () => {
        const data = {};
        new FormData(form).forEach((v,k) => data[k] = v);
        if(window.Storage) window.Storage.saveDraft(data);
      });

      const clearBtn = document.getElementById('clearStorage');
      if(clearBtn) clearBtn.addEventListener('click', ()=>{
        if(window.Storage) window.Storage.clearDraft();
        if(window.Toast) window.Toast.showToast('Rascunho limpo', {type:'info'});
        mountRoute();
      });

      form.addEventListener('submit', function(e){
        e.preventDefault();
        const ok = window.Validation ? window.Validation.validateForm(form) : form.checkValidity();
        if(!ok){
          if(window.Toast) window.Toast.showToast('Corrija os erros antes de enviar.', {type:'error'});
          return;
        }
        const data = {};
        new FormData(form).forEach((v,k) => data[k] = v);
        window.Storage && window.Storage.clearDraft();
        if(window.Toast) window.Toast.showToast('Cadastro enviado com sucesso!', {type:'info'});
        console.log('Dados enviados (simulado):', data);
      });
    }
  }

  window.addEventListener('hashchange', mountRoute);
  window.addEventListener('DOMContentLoaded', mountRoute);
})();