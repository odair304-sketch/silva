
(function(exports){
  const templates = {};

  templates.home = function(){
    return `
      <section class="hero" aria-labelledby="hero-title">
        <h1 id="hero-title">Nome da Organização — Transformando Vidas</h1>
        <p>Trabalhamos com voluntariado, educação e apoio à comunidade.</p>
        <img src="assets/img/hero.jpg" alt="Voluntários em ação" />
      </section>
      <section aria-labelledby="about-title">
        <h2 id="about-title">Sobre a organização</h2>
        <p>Missão, visão e valores.</p>
      </section>
    `;
  };

  templates.projetos = function(){
    return `
      <h1>Projetos Sociais</h1>
      <div class="cards" aria-live="polite">
        <article class="card"><img src="assets/img/projeto-1.jpg" alt=""><div class="card-content"><h3>Oficina de Alfabetização</h3><p>Descrição do projeto.</p></div></article>
        <article class="card"><img src="assets/img/projeto-1.jpg" alt=""><div class="card-content"><h3>Banco de Alimentos</h3><p>Descrição do projeto.</p></div></article>
      </div>
    `;
  };

  templates.cadastro = function(data = {}){
    const { nome = '', email = '', cpf = '', telefone = '', nascimento = '', cep = '', endereco = '', cidade = '', estado = '' } = data;
    return `
      <h1>Cadastro de Voluntário</h1>
      <form id="cadastroForm" novalidate>
        <fieldset><legend>Dados pessoais</legend>
          <label for="nome">Nome completo *</label>
          <input id="nome" name="nome" type="text" required minlength="3" value="${nome}" />
          <label for="email">E-mail *</label>
          <input id="email" name="email" type="email" required value="${email}" />
          <label for="cpf">CPF *</label>
          <input id="cpf" name="cpf" type="text" inputmode="numeric" required placeholder="000.000.000-00" value="${cpf}" />
          <label for="telefone">Telefone *</label>
          <input id="telefone" name="telefone" type="tel" inputmode="tel" required placeholder="(00) 00000-0000" value="${telefone}" />
          <label for="nascimento">Data de Nascimento *</label>
          <input id="nascimento" name="nascimento" type="date" required value="${nascimento}" />
        </fieldset>
        <fieldset><legend>Endereço</legend>
          <label for="cep">CEP *</label>
          <input id="cep" name="cep" type="text" required inputmode="numeric" placeholder="00000-000" value="${cep}" />
          <label for="endereco">Endereço *</label>
          <input id="endereco" name="endereco" type="text" required value="${endereco}" />
          <label for="cidade">Cidade *</label>
          <input id="cidade" name="cidade" type="text" required value="${cidade}" />
          <label for="estado">Estado *</label>
          <select id="estado" name="estado" required>
            <option value="">Escolha...</option>
            <option value="SP" ${estado==='SP'?'selected':''}>São Paulo</option>
            <option value="RJ" ${estado==='RJ'?'selected':''}>Rio de Janeiro</option>
            <option value="MG" ${estado==='MG'?'selected':''}>Minas Gerais</option>
          </select>
        </fieldset>
        <div style="display:flex;gap:12px;align-items:center">
          <button class="btn-primary" type="submit">Enviar cadastro</button>
          <button type="button" id="clearStorage">Limpar rascunho</button>
        </div>
      </form>
    `;
  };

  function render(templateName, container, data){
    const tpl = templates[templateName];
    if(!tpl) { container.innerHTML = '<p>Rota não encontrada.</p>'; return; }
    container.innerHTML = tpl(data);
  }

  exports.Templates = { render };
})(window);
