
(function(exports){
  function showToast(message, opts={type:'info', timeout:3000}){
    let container = document.querySelector('.toast-container');
    if(!container){
      container = document.createElement('div');
      container.className = 'toast-container';
      container.style.position = 'fixed';
      container.style.right = '16px';
      container.style.bottom = '16px';
      container.style.zIndex = 2000;
      document.body.appendChild(container);
    }
    const t = document.createElement('div');
    t.className = 'toast';
    t.textContent = message;
    t.style.background = opts.type==='error' ? 'var(--color-danger)' : 'var(--color-primary)';
    t.style.color = 'white';
    t.style.padding = '10px 14px';
    t.style.borderRadius = '8px';
    t.style.marginTop = '8px';
    container.appendChild(t);
    setTimeout(()=>{ t.remove(); }, opts.timeout || 3000);
  }

  exports.Toast = { showToast };
})(window);
