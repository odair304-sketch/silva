
(function(exports){
  const KEY = 'cadastro_rascunho_v1';

  function saveDraft(data){
    try{
      localStorage.setItem(KEY, JSON.stringify(data));
    }catch(e){ console.error('storage save failed', e); }
  }

  function loadDraft(){
    try{
      const raw = localStorage.getItem(KEY);
      return raw ? JSON.parse(raw) : null;
    }catch(e){ return null; }
  }

  function clearDraft(){
    try{ localStorage.removeItem(KEY); }catch(e){}
  }

  exports.Storage = { saveDraft, loadDraft, clearDraft };
})(window);
