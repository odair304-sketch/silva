# 🌍 Projeto HTML5 — Organização Exemplo
Projeto desenvolvido como entrega da disciplina de fundamentos de HTML5, aplicando semântica, formulários complexos e multimídia.
